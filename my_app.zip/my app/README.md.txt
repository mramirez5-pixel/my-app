# Aplicación PHP + MySQL – Gestión de Tienda

## Requisitos
- PHP 7 o superior
- MySQL / MariaDB
- Servidor local (XAMPP, WAMP o similar)

## Instalación
1. Crear la base de datos ejecutando:
   - `sql/bd.sql`
2. Configurar conexión en:
   - `config/conexion.php`
3. Copiar el proyecto en:
   - `htdocs` (XAMPP)
4. Abrir en navegador:
   - `http://localhost/mi_app`

## Funcionalidades

### Clientes
- Crear, Editar, Borrar (lógico)
- Listar
- Buscar por nombre

### Productos
- Crear, Editar, Borrar (lógico)
- Listar
- Buscar por nombre

### Pedidos
- Crear pedido
- Listar pedidos mostrando cliente y producto

## Autor
Alumno – Práctica individual
